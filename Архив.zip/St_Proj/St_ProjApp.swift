//
//  St_ProjApp.swift
//  St_Proj
//
//  Created by user on 07.10.2024.
//

import SwiftUI

@main
struct St_ProjApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
