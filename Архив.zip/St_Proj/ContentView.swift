//
//  ContentView.swift
//  St_Proj
//
//  Created by user on 07.10.2024.
//

import SwiftUI

struct ContentView: View {
    @State private var username: String = ""
    @State private var number: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isCheck: Bool = false
    var attributedString: AttributedString {
      var attributedText = AttributedString(" Term and conditions and private policy")
        attributedText.link = URL(string: "https://fivestars.blog")
      return attributedText
    }
    var body: some View{
        VStack{
            VStack(alignment: .leading){
                Text("Create an account")
                    .fontWeight(.black)
                Text("Complete the sign up proccess to get started")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            .frame(maxWidth: .infinity,alignment: .leading)
            .padding([.leading,.trailing],10)
            
            VStack(alignment: .leading){
                Text("Full name").foregroundColor(.gray)
                TextField("Ivanov Ivan", text: $username)
                    .padding(10)
                    .border(Color.gray)
                    .cornerRadius(3.5)
            }
            .padding([.leading,.trailing, .top], 10)
            .frame(maxWidth: .infinity,alignment: .leading)
            
            VStack(alignment: .leading){
                Text("Phone number").foregroundColor(.gray)
                TextField("+7(999)999-99-99", text: $number)
                    .padding(10)
                    .border(Color.gray)
                    .cornerRadius(3.5)
            }
            .padding([.leading,.trailing, .top], 10)
            .frame(maxWidth: .infinity,alignment: .leading)
            
            VStack(alignment: .leading){
                Text("Email Address").foregroundColor(.gray)
                TextField("***********@mail.com", text: $email)
                    .padding(10)
                    .border(Color.gray)
                    .cornerRadius(3.5)
            }
            .padding([.leading,.trailing, .top], 10)
            .frame(maxWidth: .infinity,alignment: .leading)
            
            VStack(alignment: .leading){
                Text("Password").foregroundColor(.gray)
                SecureField("*********", text: $password)
                    .padding(10)
                    .border(Color.gray)
                    .cornerRadius(3.5)
            }
            .padding([.leading,.trailing, .top], 10)
            .frame(maxWidth: .infinity,alignment: .leading)
            
            VStack(alignment: .leading){
                Text("Confirm Password").foregroundColor(.gray)
                SecureField("********", text: $password)
                    .padding(10)
                    .border(Color.gray)
                    .cornerRadius(3.5)
            }
            .padding([.leading,.trailing, .top], 10)
            .frame(maxWidth: .infinity,alignment: .leading)
            VStack(alignment: .leading){
                CheckBox(value: $isCheck)
                    .padding(.trailing, 10)
                Text("By ticking this box,you agree to out")
                + Text(attributedString)
                    .underline()
                    .foregroundColor(.yellow)
            }
            .padding([.leading,.trailing, .top], 10)
            .frame(maxWidth: .infinity,alignment: .leading)
        }
        .font(.custom("Roboto-Italic", size: 14))
    }
}
    #Preview {
        ContentView()
    }
